const header=document.querySelector('.site-header');
window.addEventListener('scroll',()=>{header.style.background=window.scrollY>80?'rgba(6,36,25,.94)':'rgba(6,36,25,.82)'});
